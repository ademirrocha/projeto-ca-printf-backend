    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">  
    <link rel="stylesheet" href="css/templatemo-style.css">
    <section id="tmPortfolio">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="tm-portfolio-item">
              <div class="tm-portfolio-name text-white tm-bg-green">
                <h1 class="card-title h1">Projetos</h1>
              </div>
              <div class="card" style="width: 18rem;">
  <div class="card-body">
    <h5 class="card-title">Fábrica de Software</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="card-link">Card link</a>
    <a href="#" class="card-link">Another link</a>
  </div>
</div>
              <div class="tm-portfolio-description">
                <h3 class="tm-text-green">
                  Fábrica de Software
                  <span class="tm-title-small">2020</span>
                </h3>
                <p class="mb-0">
                  A Fábrica de software é um conjunto de recursos, processos e metodologias estruturados de forma semelhante àqueles das indústrias tradicionais, utilizando as melhores práticas criadas para o processo de desenvolvimento, testes e manutenções dos softwares.
                </p>
              </div>
            </div>
      </div>
    </div>
  </div>


</section>
 <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>